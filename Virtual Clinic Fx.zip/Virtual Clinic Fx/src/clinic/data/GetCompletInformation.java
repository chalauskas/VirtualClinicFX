package clinic.data;

public interface GetCompletInformation {

        public void showAllData();
    }


