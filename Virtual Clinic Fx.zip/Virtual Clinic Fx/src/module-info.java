module Virtual.Clinic.Fx {
    requires javafx.fxml;
    requires javafx.controls;

    opens clinic.fx;
}